INTRODUCTION
------------

This script is designed for migrating the data and images between softlayer accounts. Data migration will migrate the data of one or more containers from one softlayer account to the another, and in the same way, image migration will migrate one or more or all the images between two softlayer accounts.

REQUIREMENTS
------------

The migration script requires:

1) A linux system - Red Hat Enterprise Linux Server release 7.1
2) Python swift client. 
   Check if the python swift client is installed or not:
   - Execute below command
	 >> swift 
	    - If this shows "-bash: swift: command not found" then, swift client is not present on your system. Please refer "Steps to install swiftclient" to install it.


INSTALLATION
------------

1) Get the SL_dev.zip from : https://github.com/mital27/Softlayer-Migration
2) Unzip SL_dev on your linux system.
3) Change file permissions of the migration script 
   Use: chmod 777 /SL_dev/script/master.sh

CONFIGURATION
-------------

- Configuration File:  
  Configraton file is located at SL_dev/script/app.cfg. This file contains all the configurations required for the migration.

- Working Directory:
  This is the directory where SL_dev is unzipped. Modify working directory attribute to the location where you have extracted SL_dev in      configuartion file.

- Account Details:
  Migration needs two softlayer accounts, details of these accounts must be provided in the configuration file. Provide SL account and location details for the source and destination in configuration file.
 
- Image details for image migration:
  This is the name of image which you want to migrate from source to destination account. Provide the image name you want to migrate as "source_image_name" and destination image name as "dest_image_name" (If you want to change the name of image after migration). If dest_image_name is not provided, it will consider the source image name as destination image name. If you want to migrate all the images provide source_image_name as "all" and in case of multiple images seperate the same with comma.

- Data migration details:
  This is the container which will be migrated between accounts. Provide name of the source_container for data migration and keep source_objects to "all" always. If you want to migrate image and data at the same time, please provide source_image_name and source_objects. If you want only one migration to be done then keep the other attribute blank.

- Container Details:
  Containers on the object store of your Softlayer account will be used to upload and download the data. Provide the source and destination containers on and from which the image/data will be downloaded and uploaded.
 
- Account Files:
  These files are used to authenticate the softlayer accounts. Rename file "accountname_location.sh" to youraccountname_location.sh, and provide the details as per your SL account and location for source and destination.
  
- Mount Point:
  This is the path to a directory where the data/image files will be downloaded loally. Rename "mount_point" to the directory where you want to download the data locally.

EXECUTION
---------

Execute the migaration script as below:
1) Change your path to the SL_dev/script
   Use: cd {path_where_the_folder_is_extracted}/SL_dev/script
   Example : cd /tmp/SL_dev/script (Here SL_dev is extracted at '/tmp' )
   
2) Execute below command:
	./master.sh
	
RESULTS
-------

Once the script is executed successfully, you will be able to see below results:

1) Container would be migrated from source account to destination account. You will see the same copy of container on destination acount as that of source account.
2) You will see the image that you migrated in the image list of destination account.
3) You can see the time required by download and upload for container and image in the report file, this file is accessible at /SL_dev/reports/Migration_report.txt. If you do not see statistics for last execution then there are chances that script was executed unuccessfully. You can access this file using - vi /SL_dev/reports/Migration_report.txt
4) Log file will be generated for script execution. There will be a log file for each execution of the script with the date and time of script execution at /SL_dev/logs. You can access this file using - vi /SL_dev/reports/{log_file_name}.txt
	
TROUBLESHOOTING
---------------

1) If the script fails to execute with "-bash: ./master.sh: Permission denied", verify that you have changed the mode of script to make it executable.

2) If report file does not show last execution statistic, then there might be an issue in the script execution. Please check respective log file for the issues occured during execution.

