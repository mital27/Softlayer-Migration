import SoftLayer
import json
import sys

# Your SoftLayer API username and key.
USERNAME=sys.argv[1]
API_KEY=sys.argv[2]

client = SoftLayer.Client(username=USERNAME, api_key=API_KEY)

#Create account object to get the id
accountService = client['SoftLayer_Account']

objectMask = "mask[children[storageRepository[datacenter],blockDevices[diskImage[type]]]]"
imageName=sys.argv[3]

#Get the image size in bytes
try:
    result = accountService.getPrivateBlockDeviceTemplateGroups(mask=objectMask)
    i = 0
    for r in result:
     children = r['children']
     id = r['id']
     for child in children:
      name=child['name']
      if name == imageName:
        imageTemplateId = id
except SoftLayer.SoftLayerAPIError as e:
    """
    # If there was an error returned from the SoftLayer API then bomb out with the
    # error message.
    """
    print("Unable to retrieve the tempalteId. faultCode=%s, faultString=%s" % (e.faultCode, e.faultString))
    exit(1)

#Create image service object for image realted functions
imageService = client['SoftLayer_Virtual_Guest_Block_Device_Template_Group']

# The URL the object storage in your account where you wish to copy the image template.
uri = sys.argv[4]

template = {
'name': imageName,
'uri': uri
}

try:
	result = imageService.copyToExternalSource(template, id=imageTemplateId)
	print(json.dumps(result, sort_keys=True, indent=2, separators=(',', ': ')))
except SoftLayer.SoftLayerAPIError as e:
	print("Unable to export image. faultCode=%s, faultString=%s"
	% (e.faultCode, e.faultString))
	exit(1)

