#!/usr/bin/sh
working_directory=$6
source ${working_directory}/script/app.cfg

source_acc=$source_account
source_acc+="_$source_location"

source ${working_directory}/script/$source_acc.sh

image_name=$5".vhd-0.vhd"
image_import_size=`swift stat $4 $image_name | grep 'Content Length' | awk '{print $3}'`

while true; do
 image_size=`python $working_directory/script/list_images.py $1 $2 $5`
 #image_size=${image_size%.*}
 image_size=`printf '%.0f' $image_size`
 
 if [  -z "$image_import_size" -o "$image_import_size" == " " ]
 then
 	sleep 10s
 else
	 if [ $image_size -lt $image_import_size ]
	 then
		 sleep 10s
	 else
		 break
	 fi
 fi
done
