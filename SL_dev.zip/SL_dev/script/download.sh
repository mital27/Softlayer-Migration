source $1/script/app.cfg
#Function to download the image
retry_count=0

 
downloaded_count=0
while [ $retry_count -le 3 ]; do
        download_flag=0
	if [[ $2 == *".vhd"* ]]; then
		rm -rf $mount_point/$source_image_container
		mkdir $mount_point/$source_image_container
		cd $mount_point/$source_image_container

	        swift download $source_image_container $2 --object-threads 100 --skip-identical
	else
		rm -rf $mount_point/$source_container
		mkdir $mount_point/$source_container
		cd $mount_point/$source_container
		
		swift download $source_container $2 --object-threads 100 --skip-identical
	fi

        if [ $? -ne 0 ]
        then
                retry_count=$((retry_count+1))
        else
                download_flag=1
                break
        fi
done

echo $download_flag

