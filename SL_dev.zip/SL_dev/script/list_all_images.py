import SoftLayer
import json
import sys


USERNAME=sys.argv[1]
API_KEY=sys.argv[2]
import SoftLayer
import json
import sys

# Your SoftLayer API username and key.
USERNAME = sys.argv[1]
API_KEY = sys.argv[2]

# Declare the API client
client = SoftLayer.Client(username=USERNAME, api_key=API_KEY)
accountService = client['SoftLayer_Account']

# declaring an object mask to get more information about the images templates
objectMask = "mask[children[storageRepository[datacenter],blockDevices[diskImage[type]]]]"

image_list=""
#Get the image size in bytes
try:
    result = accountService.getPrivateBlockDeviceTemplateGroups(mask=objectMask)
    i = 0
    for r in result:
     children = r['children']
     for child in children:
	name=child['name']
	image_list=image_list+","+name
	print(image_list)
except SoftLayer.SoftLayerAPIError as e:
    """
    # If there was an error returned from the SoftLayer API then bomb out with the
    # error message.
    """
    print("Unable to retrieve the list of image templates. faultCode=%s, faultString=%s" % (e.faultCode, e.faultString))

