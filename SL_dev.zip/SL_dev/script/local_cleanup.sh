source $1/script/app.cfg
#Delete the downloaded local copy of the container
if [ -d $mount_point/$source_container ]; then
	rm -rf $mount_point/$source_container
fi

delete_flag=1
#Verify for successful deletion of the Container.
if [ ! -d $mount_point/$source_container ]; then
	delete_flag=0
fi

echo $delete_flag
