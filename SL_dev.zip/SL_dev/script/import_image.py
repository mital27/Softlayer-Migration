import SoftLayer
import json
import sys


USERNAME=sys.argv[1]
API_KEY=sys.argv[2]

print("USERNAME: %s." % USERNAME)
print("API KEY: %s." % API_KEY)
client = SoftLayer.Client(username=USERNAME, api_key=API_KEY)

#Create account object for retriving osrefcode
accountService = client['SoftLayer_Account']
objectMask = "mask[children[storageRepository[datacenter],blockDevices[diskImage[type, softwareReferences[softwareDescription[referenceCode]]]]]]"

imageName=sys.argv[3]
sourceImageName=sys.argv[5]

#Get the image size in bytes
try:
    result = accountService.getPrivateBlockDeviceTemplateGroups(mask=objectMask)
    i = 0
    for r in result:
     children = r['children']
     for child in children:
      name=child['name']
      if name == sourceImageName:
        refcode=child['blockDevices'][0]['diskImage']['softwareReferences'][0]['softwareDescription']['referenceCode']
	print(name +"="+ refcode)
except SoftLayer.SoftLayerAPIError as e:
    """
    # If there was an error returned from the SoftLayer API then bomb out with the
    # error message.
    """
    print("Unable to retrieve osrefcode for the image. faultCode=%s, faultString=%s" % (e.faultCode, e.faultString))
    exit(1)

#Create image service object for image functions
imageService = client['SoftLayer_Virtual_Guest_Block_Device_Template_Group']
imageName=sys.argv[3]
uri=sys.argv[4]

osrefcode="tobeimplemented"

# Build a SoftLayer_Container_Virtual_Guest_Block_Device_Template_Configuration object
configuration = {
'name': imageName,
'note': 'Imported image',
'operatingSystemReferenceCode': refcode,
'uri': uri
}

print("Conf : %s" % configuration)
try:
	result = imageService.createFromExternalSource(configuration)
	print("import is done")
	print(json.dumps(result, sort_keys=True, indent=2, separators=(',', ': ')))	
except SoftLayer.SoftLayerAPIError as e:
	print("Unable to create image. faultCode=%s, faultString=%s"
	% (e.faultCode, e.faultString))
	exit(1)

