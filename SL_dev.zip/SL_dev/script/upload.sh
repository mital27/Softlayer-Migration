source $1/script/app.cfg

destination_account=$dest_account
destination_account+="_$dest_location"
source "$working_directory/script/$destination_account.sh"

cd $mount_point

upload_chunk_size=$3


if [[ $2 == *".vhd"* ]]; then
	cd $mount_point/$source_image_container
	swift -v upload $dest_image_container $2
elif [ "$upload_chunk_size" != " "  ]; then
	#in case of chunk_size
	swift -v upload $source_container $2 -c
else
	swift -v upload $source_container $source_container -c -S $upload_chunk_size
fi
