source $1/script/app.cfg

#Execute the script for importing image
cd $working_directory

import_success_flag=0
retry_count=0

#Create source image file name
if [[ $2 == *".vhd"* ]]; then
         source_image=$2
else
         source_image=$2".vhd-0.vhd"
fi



#Username and api key to authenticate the account
dest_username=`awk -F':' 'NR==2 {print $2}' ${working_directory}/script/${dest_account}_${dest_location}.sh`
dest_api_key=`awk -F'=' 'NR==3 {print $2}' ${working_directory}/script/${dest_account}_${dest_location}.sh`

#URI for importing the image
import_uri="swift://"$dest_account"@"$dest_location"/"$dest_image_container"/"$source_image

if [  -z "$dest_image_name" -a "$dest_image_name" != " " ]; then
     dest_image_name=$source_image_name
fi

while [ $retry_count -le 2 -a $import_success_flag -ne 1 ]; do
        #Call to the python script for import
        python $working_directory/script/import_image.py $dest_username $dest_api_key $dest_image_name $import_uri $source_image_name
        if [ $? -eq 0 ]
        then
                sh $working_directory/script/image_import_size.sh $dest_username $dest_api_key $dest_image_name $dest_image_container $source_image_name $working_directory
                import_success_flag=1
        else
                retry_count=$((retry_count+1))
        fi
done

echo $import_success_flag

