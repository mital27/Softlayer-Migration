#!/usr/bin/sh
working_directory=$6

source $working_directory/script/app.cfg
source_acc=$source_account
source_acc+="_$source_location"

source ${working_directory}/script/$source_acc.sh

image_size=`python $working_directory/script/list_images.py $1 $2 $3`
#image_size=${image_size%.*}
image_size=`printf '%.0f' $image_size`

while true; do
 image_export_size=`swift stat $4 $5 | grep 'Content Length' | awk '{print $3}'`
 if [  -z "$image_export_size" -o "$image_export_size" == " " ]
 then
 	sleep 10s
 else
	 if [ $image_export_size -lt $image_size ]
	 then
		 sleep 10s
	 else
		 break
	 fi
 fi
done
