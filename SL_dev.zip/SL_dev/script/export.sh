source $1/script/app.cfg

#Export the image
export_success_flag=0
retry_count=1

#Create the username and api key required to authenticate the account
src_username=`awk -F':' 'NR==2 {print $2}' ${working_directory}/script/${source_account}_${source_location}.sh`
src_api_key=`awk -F'=' 'NR==3 {print $2}' ${working_directory}/script/${source_account}_${source_location}.sh`

#URI for the image to be migrated
export_uri="swift://"$source_account"@"$source_location"/"$source_image_container"/"$2".vhd"

#Create source image file name
source_image=$2".vhd-0.vhd"

while [ $retry_count -le 2 -a $export_success_flag -ne 1 ]; do
        if [ `python $working_directory/script/export_image.py $src_username $src_api_key $2 $export_uri` ]
        then
                sleep 15
                #Compare image sizes, wait till the image is exported completely
                sh $working_directory/script/image_export_size.sh $src_username $src_api_key $2 $source_image_container $source_image $working_directory
                export_success_flag=1
		break
        else
                retry_count=$((retry_count+1))
        fi
done

echo $export_success_flag
