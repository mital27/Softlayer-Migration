source $2/script/app.cfg

source_acc=$source_account
source_acc+="_$source_location"
source "$working_directory/script/$source_acc.sh"

container_size=$(swift list -l | grep -w $1 | awk '{print $2}')
divisor=1024
container_size_kb=$((container_size / divisor))
device_size=$(df -k ${mount_point} | awk '{print $4}' | tail -1)

size_flag=1

if [ $container_size_kb -le $device_size ]; then
	size_flag=0
fi

echo $size_flag
