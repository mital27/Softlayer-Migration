source app.cfg

current_time=$(date '+%Y.%m.%d-%H.%M.%S')

log_directory=$working_directory/logs
log_file=migration"-"$current_time".log"

report_directory=$working_directory/reports
report_file="Migration_report.txt"
script_exe_start=$(date +"%s")

echo "INFO: $(date '+%Y.%m.%d-%H.%M.%S') : Starting migration of data">>$log_directory/$log_file

destination_account=$dest_account
destination_account+="_$dest_location"

if [ -f $working_directory/script/$destination_account.sh ]
then
        echo "INFO: $(date '+%Y.%m.%d-%H.%M.%S') : $destination_account.sh file exists">>$log_directory/$log_file
else
        echo "ERROR: $(date '+%Y.%m.%d-%H.%M.%S') : $destination_account.sh fiel does not exist. Exiting...">>$log_directory/$log_file
        echo "INFO: $(date '+%Y.%m.%d-%H.%M.%S'): Check log file $log_directory/$log_file for errors."
        exit 1
fi


source_acc=$source_account
source_acc+="_$source_location"

if [ -f $working_directory/script/$source_acc.sh ]
then
        echo "INFO: $(date '+%Y.%m.%d-%H.%M.%S') : $source_acc.sh file exists">>$log_directory/$log_file
else
        echo "ERROR: $(date '+%Y.%m.%d-%H.%M.%S') : $source_acc.sh file does not exist. Exiting...">>$log_directory/$log_file
        echo "INFO: $(date '+%Y.%m.%d-%H.%M.%S'): Check log file $log_directory/$log_file for errors."
        exit 1
fi

#Check for existence of report file in present working directory

if [ -f $report_directory/$report_file ]
then
        echo "INFO: $(date '+%Y.%m.%d-%H.%M.%S'): Report file already exixts.">>$log_directory/$log_file
else
        echo "INFO: $(date '+%Y.%m.%d-%H.%M.%S'): Report file does not exist. Creating...">$log_directory/$log_file
	divider=====================================================================================================================================================

	header="\n %-10s %15s %25s %25s %25s %10s %10s %5s\n"
	printf '%s\n' $divider > $report_directory/$report_file

	printf "$header" "Type(DM/IM) | " "SOURCE ACCOUNT | " "SOURCE CONTAINER/IMAGE | " "DESTINATION ACCOUNT | " "DESTINATION CONTAINER/IMAGE | " "D/L TIME | " "U/L TIME | " "TOTAL" >> $report_directory/$report_file

	printf '%s\n' $divider >> $report_directory/$report_file

fi

#Executing migration code

data_migration_flag=0
image_migration_flag=0
if [ ! -z "$source_objects" -a "$source_objects" != " " ]; then
	#Data migration
        echo "INFO : $(date '+%Y.%m.%d-%H.%M.%S') : Performing data migration ." >> $log_directory/$log_file
	data_migration_flag=1
	
	
	arr=$(echo $source_container | tr "," "\n")
	source "$working_directory/script/$source_acc.sh"
	container_flag=0
	object_flag=0
	container_list=`swift list`
	container_size_check=5242880

	for source_container in $arr
	do
		for container in $container_list
		do
			if [ "$source_container" = "$container" ]; then

				sh check_size.sh $container $working_directory
				
				if [ $? = 0 ];then
					#Download the container
					download_data_start=$(date +"%s")
					if [ $source_objects == all ]; then
						echo "INFO: $(date '+%Y.%m.%d-%H.%M.%S') : Downloading the image $image from source container $source_containe.">>$log_directory/$log_file
						sh download.sh $working_directory				
						
					fi
					download_data_stop=$(date +"%s")
					diff=$(($download_data_stop-$download_data_start))
					download_data_difference="$(($diff / 3600 )) h $((($diff % 3600) / 60)) m $(($diff % 60)) s"

					if [ $? = 0 ];then
                                        	echo "INFO: $(date '+%Y.%m.%d-%H.%M.%S') : Download successfull.">>$log_directory/$log_file
						
						#Download was successfull. Uploading the container.
						upload_data_start=$(date +"%s")
						source_container_size="`du -sk $mount_point/$source_container | cut -f1`"
						if [ $source_container_size -ge $container_size_check ]; then
							#Container is greater than 5GB. Upload is done in chunks.
							sh upload.sh $source_container $upload_chunk_size $working_directory
						else
							#Container size is greater less than 5GB. 
							sh upload.sh $source_container $working_directory
						fi
						upload_data_stop=$(date +"%s")
						diff=$(($upload_data_stop-$upload_data_start))
						upload_data_difference="$(($diff / 3600 )) h $((($diff % 3600) / 60)) m $(($diff % 60)) s"
						
						format="\n %-5s %25s %25s %25s %25s %10s %10s %10s\n"
						printf "$format"  "DM" "$source_acc" "$source_container" "$destination_account" "$source_container" "$download_data_difference" "$upload_data_difference" "-">> $report_directory/$report_file

						if [ $? = 0 ];then
							 echo "INFO: $(date '+%Y.%m.%d-%H.%M.%S') : Upload successfull.">>$log_directory/$log_file
							 sh local_cleanup.sh $working_directory

							 if [ $? = 0 ];then
								echo "INFO: $(date '+%Y.%m.%d-%H.%M.%S') : Successfully deleted the downloaded container.">>$log_directory/$log_file
							 else
								echo "INFO: $(date '+%Y.%m.%d-%H.%M.%S') : Failed to delete the downloaded container.">>$log_directory/$log_file
							 fi
						else
							 echo "ERROR: $(date '+%Y.%m.%d-%H.%M.%S') : Upload failed. Exiting..">>$log_directory/$log_file
							 exit 1
						fi
                                        else
                                                echo "ERROR: $(date '+%Y.%m.%d-%H.%M.%S') : Download failed. Exiting..">>$log_directory/$log_file
                                                exit 1
                                        fi
				else
					echo "ERROR : $(date '+%Y.%m.%d-%H.%M.%S') : Container could not be download as the available space on the device is low. Exiting..." >> $log_directory/$log_file
					exit 1
				fi		
			fi
			
		done
	done
fi

	
if [ ! -z "$source_image_name" -a "$source_image_name" != " " ]; then
	#Image migration
	source "$working_directory/script/$source_acc.sh"
	echo "INFO : $(date '+%Y.%m.%d-%H.%M.%S') : Performing image migration ." >> $log_directory/$log_file
	image_migration_flag=1
	
	#Create source image file name
	source_image=$source_image_name".vhd-0.vhd"

#	sh export.sh $source_image_name $working_directory
	if [ $? = 0 ];then
		#Export successful
		echo "INFO: $(date '+%Y.%m.%d-%H.%M.%S') : Image exported successfully.">>$log_directory/$log_file
		container_list=`swift list`
		for container in $container_list
		do
			if [ "$source_image_container" = "$container" ]; then
				sh check_size.sh ${container} $working_directory
				if [ $? = 0 ];then
					echo "INFO: $(date '+%Y.%m.%d-%H.%M.%S') : Downloading the image." >> $log_directory/$log_file
					if [ $source_image_name == all ]; then
						#Get list of all the images and export each in loop
						src_username=`awk -F':' 'NR==2 {print $2}' ${working_directory}/script/${source_account}_${source_location}.sh`
						src_api_key=`awk -F'=' 'NR==3 {print $2}' ${working_directory}/script/${source_account}_${source_location}.sh`
						list_of_images=python list_all_images.py src_username src_api_key
						
						array_of_all_images=$(echo $list_of_images | tr "," "\n")

						for image_to_export in $array_of_all_images
						do
							export.sh $working_directory $image_to_export
						done
						source "$working_directory/script/$source_acc.sh"
						object_list=`swift list $source_image_container | grep ".vhd$"`

						for image in $object_list 
						do
							download_image_start=$(date +"%s")
							#Call the download function
							sh download.sh $working_directory $image
							
							if [ $? = 0 ];then
								download_image_stop=$(date +"%s")
								diff=$(($download_image_stop-$download_image_start))
								download_image_difference="$(($diff / 3600 )) h $((($diff % 3600) / 60)) m $(($diff % 60)) s"
								echo "INFO: $(date '+%Y.%m.%d-%H.%M.%S') : Image-$image downloaded successfully.">>$log_directory/$log_file
								#Checking for destination container
								#Check if destination container exists or not
								dest_container_flag=0
								dest_container_list=`swift list`
								for container in $dest_container_list
								do
								    if [ "$dest_image_container" = "$container" ]
								    then
										dest_container_flag=1
										break
								    fi
								done

								#Creation of destination container if it doesnot exists.

								if [ ! $dest_container_flag = 1 ]; then
								        swift post $dest_image_container
								        dest_container_flag=1
								else
								        dest_container_flag=0
								fi

								#Uploading the image
								upload_image_start=$(date +"%s")
								sh upload.sh $working_directory $image
	
								if [ $? = 0 ];then
									upload_image_stop=$(date +"%s")
									diff=$(($upload_image_stop-$upload_image_start))
									upload_image_difference="$(($diff / 3600 )) h $((($diff % 3600) / 60)) m $(($diff % 60)) s"
						
									if [ ! -z "$dest_image_name" -a "$dest_image_name" != " " ]; then
										echo "WARNING : $(date '+%Y.%m.%d-%H.%M.%S') : Destnation image name is not specified,so using the same as of source name." >> $log_directory/$log_file
										dest_image_name=$source_image_name
									fi
									
									format="\n %5s %25s %25s %25s %25s %10s %10s %10s\n"
									printf "$format"  "IM" "$source_acc" "$source_image_name" "$destination_account" "$dest_image_name" "$download_image_difference" "$upload_image_difference" "-">> $report_directory/$report_file
									
									sh local_cleanup.sh $working_directory
									#Importing the image
									sh import.sh $image $working_directory
									source "$working_directory/script/$destination_account.sh"
                                                                        echo "INFO : $(date '+%Y.%m.%d-%H.%M.%S') : Performing clean-up activities" >> $log_directory/$log_file
                                                                        if [ $dest_container_flag -ne 1 ]
                                                                        then
                                                                        	swift delete $dest_container
                                                                        else
                                                                                swift delete $dest_container $image
                                                                        fi

                                                                        source "$working_directory/script/$source_acc.sh"
                                                                        swift delete $source_container $image

								else
									echo "ERROR: $(date '+%Y.%m.%d-%H.%M.%S') : Upload for $source_image_container failed. Exiting.."
									exit 1
								fi
							else
								echo "ERROR: $(date '+%Y.%m.%d-%H.%M.%S') : Download was failed for $image. Exiting.."
								exit 1
							fi
						done
					else

						array_of_images=$(echo $source_image_name | tr "," "\n")
						
						downloaded_image_count=0
						for image in $array_of_images 
						do	
							sh export.sh $working_directory "$image"
							source "$working_directory/script/$source_acc.sh"
	                                                object_list=`swift list $source_image_container | grep ".vhd$"`
			
							image_found_flag=0
							for object in $object_list
							do
								image_name=$image".vhd-0.vhd"
								if [ "$image_name" == "$object" ]; then				 												download_image_start=$(date +"%s")
									 sh download.sh $working_directory "$image_name"
									 if [ $? = 0 ];then
										download_image_stop=$(date +"%s")
										diff=$(($download_image_stop-$download_image_start))
										download_image_difference="$(($diff / 3600 )) h $((($diff % 3600) / 60)) m $(($diff % 60)) s"
		                                                                echo "INFO: $(date '+%Y.%m.%d-%H.%M.%S') : Image-$image downloaded successfully.">>$log_directory/$log_file
										echo "INFO: $(date '+%Y.%m.%d-%H.%M.%S') : Image-$image downloaded successfully.">>$log_directory/$log_file
		                                                                #Checking for destination container
                		                                                #Check if destination container exists or not
                                		                                dest_container_flag=0
                                                		                dest_container_list=`swift list`
		                                                       		for container in $dest_container_list
                        		                                        do
		                                                                    if [ "$dest_image_container" = "$container" ]; then
                                		                                               dest_container_flag=1
                                                		                               break
                                                                		    fi
		                                                                done
		
                		                                                #Creation of destination container if it doesnot exists.
		
                		                                                if [ ! $dest_container_flag = 1 ]; then
                        	        		                                swift post $dest_image_container
                	                                 	                        dest_container_flag=1
		                                                                else
                                		                                        dest_container_flag=0
                                                		                fi
										
													
			                                                        #Uploading the image
										echo "INFO : $(date "+%Y.%m.%d-%H.%M.%S") : Starting upload of image..">>$log_directory/$log_file
										upload_image_start=$(date +"%s")
                                		                                sh upload.sh $working_directory "$image_name"
										
                                                		                if [ $? = 0 ];then
                                                                			upload_image_stop=$(date +"%s")
											diff=$(($upload_image_stop-$upload_image_start))
											upload_image_difference="$(($diff / 3600 )) h $((($diff % 3600) / 60)) m $(($diff % 60)) s"	
											if [ ! -z "$dest_image_name" -a "$dest_image_name" != " " ]; then
												echo "WARNING : $(date '+%Y.%m.%d-%H.%M.%S') : Destnation image name is not specified,so using the same as of source name." >> $log_directory/$log_file
												dest_image_name=$source_image_name
											fi
										
											format="\n %5s %25s %25s %25s %25s %10s %10s %10s\n"
											printf "$format"  "IM" "$source_acc" "$source_image_name" "$destination_account" "$dest_image_name" "$download_image_difference" "$upload_image_difference" "-">> $report_directory/$report_file

											echo "INFO : $(date "+%Y.%m.%d-%H.%M.%S") : Upload successfull.">>$log_directory/$log_file
	
		                                                                        #Importing the image
		                                                                        sh import.sh $working_directory "$image"
											sleep 30
											sh local_cleanup.sh $working_directory
											source "$working_directory/script/$destination_account.sh"
											echo "INFO : $(date '+%Y.%m.%d-%H.%M.%S') : Performing clean-up activities" >> $log_directory/$log_file

											
											if [ $dest_container_flag = 1 ]; then
												swift delete $dest_image_container
											else
												swift delete $dest_image_container $image_name
											fi

											source "$working_directory/script/$source_acc.sh"
											swift delete $source_image_container $image_name
										
                		                                                else
                                		                                        echo "ERROR: $(date '+%Y.%m.%d-%H.%M.%S') : Upload for $source_image_container failed. Exiting.." >> $log_directory/$log_file
                                                		                        exit 1
                                                                		fi
	                                                              		

										
                		                                         else
                                 		                                echo "INFO: $(date '+%Y.%m.%d-%H.%M.%S') : Download was failed for $image. Exiting.." >> $log_directory/$log_file
                                                 		         fi
								fi
							done
				
						done
					fi		
				else
					echo "ERROR : $(date '+%Y.%m.%d-%H.%M.%S') : Container could not be download as the available space on the device is low. Exiting..." >> $log_directory/$log_file
                                        exit 1

				fi
			fi
		done
	else
		echo "ERROR: $(date '+%Y.%m.%d-%H.%M.%S') : Exporting the image failed. Exiting..">>$log_directory/$log_file
		exit 1
	fi
fi

if [ $data_migration_flag -ne 1 -a $image_migration_flag -ne 1 ]; then
	echo "ERROR : $(date '+%Y.%m.%d-%H.%M.%S') : Could not find source_objects or source_image_name to be migrated." >> $log_directory/$log_file
else
	#Stamp end time of the script to report file.
	script_exe_stop=$(date +"%s")
	script_exe_diff=$(($script_exe_stop-$script_exe_start))
	script_difference="$(($script_exe_diff / 3600 )) h $((($script_exe_diff % 3600) / 60)) m and $(($script_exe_diff % 60)) s"

	format="\n %5s %25s %25s %25s %25s %10s %10s %10s\n"
	printf "$format"  "Script" "$source_acc" "-" "$destination_account" "-" "-" "-" "$script_difference">> $report_directory/$report_file
	echo -e "\n INFO : $(date '+%Y.%m.%d-%H.%M.%S') : Time required for the script execution $script_difference.">>$log_directory/$log_file
	echo "Check log file $log_directory/$log_file for all migration related details."
fi
